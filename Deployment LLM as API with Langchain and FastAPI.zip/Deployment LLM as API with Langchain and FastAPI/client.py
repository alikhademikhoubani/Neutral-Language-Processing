import requests
import streamlit as st 

def get_openai_response(input_text):
    response = requests.post(
        "http://localhost:8000/essay/invoke",
        json={'input': {'topic': input_text}}
    )
    data = response.json()
    # فقط متن اصلی را برگردان
    return data["output"]["content"]

def get_ollama_response(input_text):
    response = requests.post(
        "http://localhost:8000/poem/invoke",
        json={'input': {'topic': input_text}}
    )
    data = response.json()
    return data['output']

st.title("LangChain Demo")

input_text = st.text_input("Essay topic")
input_text1 = st.text_input("Poem topic")

if input_text:
    st.write(get_openai_response(input_text))

if input_text1:
    st.write(get_ollama_response(input_text1))
