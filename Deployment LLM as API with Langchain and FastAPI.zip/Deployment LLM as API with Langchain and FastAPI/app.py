from fastapi import FastAPI 
from langchain_core.prompts import ChatPromptTemplate
from langserve import add_routes
import uvicorn
import os
from langchain_ollama import OllamaLLM
from langchain_groq import ChatGroq

app = FastAPI(
    title = "Langchain Server",
    version = "1.0",
    description = "A simple API Server"
)

model = ChatGroq(
    model_name = "openai/gpt-oss-20b",
    groq_api_key = "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",
    temperature = 0
)

llm = OllamaLLM(model = "llama3")

prompt1 = ChatPromptTemplate.from_template("Write me an essay about {topic} with 100 words")
prompt2 = ChatPromptTemplate.from_template("Write me a poem about {topic} with 100 words")

add_routes(
    app,
    prompt1|model,
    path = "/essay"
)

add_routes(
    app,
    prompt2|llm,
    path = "/poem"
)

if __name__ == "__main__":
    uvicorn.run(app, host = "localhost", port = 8000)