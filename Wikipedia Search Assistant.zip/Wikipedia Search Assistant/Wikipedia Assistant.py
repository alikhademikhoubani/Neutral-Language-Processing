import streamlit as st 
from langchain_groq import ChatGroq
from langchain.agents import load_tools, initialize_agent, AgentType


llm = ChatGroq(
    model_name = "llama-3.3-70b-versatile",
    groq_api_key = "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",
    temperature = 0
)


tools = load_tools(["wikipedia"], llm = llm)


agent = initialize_agent(
    tools,
    llm,
    agent = AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    handle_parsing_errors = True,
    verbose = False
)


st.set_page_config(
    page_title = "Wikipedia Tool",
    layout = "centered",
    initial_sidebar_state = "collapsed"
)


st.header("Wikipedia Tool")

prompt = st.text_input("Wikipedia search")

submit = st.button("Search")

if submit:
    if prompt:
        st.write(agent.run(prompt))
    else:
        st.warning("Please enter your prompt")