import streamlit as st 
from langchain_groq import ChatGroq
from langchain.prompts import PromptTemplate
from langchain_community.tools.youtube.search import YouTubeSearchTool
from langchain.agents import initialize_agent, AgentType


llm = ChatGroq(
    model_name = "qwen/qwen3-32b",
    groq_api_key = "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",
    temperature = 0
)


prompt_template = PromptTemplate(
    template = """
    در مورد موضوع {subject} به تعداد {number} ویدیو به من ارائه کن. ویدیوهایی که به من ارائه می کنی، باید مرتبط ترین و جدیدترین ویدیوها با موضوع مورد نظر باشند.
    """,
    input_variables = ["subject", "number"]
)


youtube_tool = YouTubeSearchTool(description = "جستجوی ویدیوهای مرتبط در YouTube. ورودی باید به صورت <موضوع>، <تعداد> باشد.")


tools = [youtube_tool]


agent = initialize_agent(
    tools,
    llm = llm,
    agent = AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    handle_sparsing_errors = True,
    verbose = False
)


st.header("YouTube Searcher")

subject = st.text_area("Enter the Subject")

number = st.text_area("Enter Number of Videos")

submit = st.button("Search")

if submit:
    if subject and number:
        st.write(agent.run(prompt_template.format(subject = subject, number = number).strip()))
    else:
        st.warning("Please Enter the Subject and Number of Videos")