import streamlit as st
#from langchain_google_genai import ChatGoogleGenerativeAI
import os
from langchain_groq import ChatGroq
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain


def generate_response(context, n_words):
    llm = ChatGroq(
        model_name = "llama-3.3-70b-versatile",
        groq_api_key = "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",
        temperature = 0.01
    )

    prompt = """
    تو یک دستیار خبره در خلاصه سازی متون هستی. متن زیر را در {n_words} کلمه خلاصه کن.
    متن: {context}
    """

    prompt_template = PromptTemplate(
        template = prompt,
        input_variables = ["context", "n_words"]
    )

    chain = LLMChain(
        llm = llm, 
        prompt = prompt_template
    )
    response = chain.run({
        "context": context,
        "n_words": n_words
    })
    return response



st.set_page_config(page_title = "Text Summarization",
page_icon = "_",
layout = 'centered',
initial_sidebar_state = 'collapsed'
)

st.header("Text Summarization")

context = st.text_input("Enter your text")

n_words = st.text_input("Number of words")

submit = st.button("Summarize")

if submit:
    if context and n_words:
        st.write(generate_response(context, n_words))
    else:
        st.warning("لطفا متن و تعداد کلمات را وارد کنید")