import streamlit as st 
import os
from langchain_groq import ChatGroq
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.chains import SequentialChain

llm = ChatGroq(
    model_name = "llama-3.3-70b-versatile",
    groq_api_key = "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",
    temperature = 0
)

template_one = PromptTemplate(
    template = """تو یک دستیار تولید محتوا در زمینه مهندسی کامپیوتر هستی.
    کار تو این است که درباره موضوعی که در ادامه به تو داده می شود، به طور کامل و جامع تحقیق و بررسی کنی و در نهایت برای آن موضوع، تولید محتوا کنی.
    محتوای تولید شده از سوی تو باید یک بخش مقدمه، بخش بدنه متن، و در نهایت یک بخش نتیجه گیری داشته باشد.
    موضوع: {subject}
    """,
    input_variables = ["subject"]
)
chain_one = LLMChain(
    llm = llm,
    prompt = template_one,
    output_key = "context"
)


template_two = PromptTemplate(
    template = """
    تو یک دستیار خبره در ترجمه متون به زبان {language} هستی. متنی که در اختیار تو هست را به زبان {language} ترجمه کن.
    متن: {context}
    """,
    input_variables = ["context", "language"]
)
chain_two = LLMChain(
    llm = llm,
    prompt = template_two,
    output_key = "final_context"
)

final_chain = SequentialChain(
    chains = [chain_one, chain_two],
    input_variables = ["subject", "language"],
    output_variables = ["final_context"]
)

st.set_page_config(page_title = "Computer Engineering Content Creator",
layout = 'centered',
initial_sidebar_state = 'collapsed'
)

st.header("Computer Engineering Content Creator")

subject = st.text_input("Enter your subject")

language = st.text_input("Enter your language")

submit = st.button("Generate")

if submit:
    if subject and language:
        st.write(final_chain.run({"subject": subject, "language": language}))
    else:
        st.warning("Please Enter Subject and Language")