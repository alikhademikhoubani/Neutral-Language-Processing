import os
from langchain_google_genai import ChatGoogleGenerativeAI
import PyPDF2 as pdf 
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.prompts import ChatPromptTemplate
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains import create_retrieval_chain
from dotenv import load_dotenv
import streamlit as st 
from langchain.schema import Document

load_dotenv()

google_api_key = os.getenv("GOOGLE_API_KEY")
os.environ["GOOGLE_API_KEY"] = os.getenv("GOOGLE_API_KEY")

st.title("Gemma Model Document Q&A")

llm = ChatGoogleGenerativeAI(
    model = "gemma-3-12b-it",
    google_api_key = google_api_key,
    temperature = 0
)

prompt = ChatPromptTemplate.from_template(
    """
    فقط بر اساس متن ارائه شده، به سوال پاسخ بده.
    متن: {context}
    سوال: {input}
    """
)


def vector_store():
    if "vectors" not in st.session_state:
        st.session_state.reader = pdf.PdfReader("C:/Users/Lenovo/Desktop/New folder (6)/rooze.pdf")
        st.session_state.texts = ""
        for page in st.session_state.reader.pages:
            st.session_state.extracted = page.extract_text()
            if st.session_state.extracted:
                st.session_state.texts += st.session_state.extracted
    
    st.session_state.splitter = RecursiveCharacterTextSplitter(
        separators = ["\n\n", "\n", " "],
        chunk_size = 1500,
        chunk_overlap = 150
    )
    st.session_state.chunks = st.session_state.splitter.split_text(st.session_state.texts)

    st.session_state.docs = [Document(page_content = chunk) for chunk in st.session_state.chunks]

    st.session_state.embeddings = GoogleGenerativeAIEmbeddings(model = "models/embedding-001")

    st.session_state.vectors = FAISS.from_documents(st.session_state.docs, embedding = st.session_state.embeddings)


input_text = st.text_input("What you want to ask from the documents?")

if st.button("Embedding Vectors"):
    if "vector" not in st.session_state:
        vector_store()
        st.write("Vector Store DB is Ready")

if input_text:
    document_chain = create_stuff_documents_chain(llm, prompt)
    retriever = st.session_state.vectors.as_retriever()
    retrieval_chain = create_retrieval_chain(retriever, document_chain)
    response = retrieval_chain.invoke({"input": input_text})
    st.write(response["answer"])