from fastapi import FastAPI
from playwright.async_api import async_playwright
import asyncio

app = FastAPI(title="Weather Scraper API")

@app.get("/")
async def home():
    return {"message": "Weather Scraper API is running"}

@app.get("/weather")
async def get_weather(city: str):
    forecast_list = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        await page.goto("https://abohavachetore.ir/")
        await page.wait_for_selector("input#search-input-fe332bc")

        # سرچ
        await page.fill("input#search-input-fe332bc", city)
        await asyncio.sleep(1)
        await page.keyboard.press("Enter")
        await asyncio.sleep(2)

        # کلیک روی شهر
        await page.click(f"a:has-text('{city}')")
        await asyncio.sleep(3)

        # گرفتن لیست forecast
        items = await page.query_selector_all("details.firelight-weather__forecast-item")

        for item in items:
            get = lambda sel: item.query_selector(sel)

            day_header = await (await get(
                ".firelight-weather__forecast-item-header-right .firelight-weather__forecast-item-header-date"
            )).inner_text()

            day_desc = await (await get(
                ".firelight-weather__forecast-item-header-right .firelight-weather__forecast-item-header-description"
            )).inner_text()

            temp_min = await (await get(
                ".firelight-weather__forecast-item-header-temp-min"
            )).inner_text()

            temp_max = await (await get(
                ".firelight-weather__forecast-item-header-temp-max"
            )).inner_text()

            day_temp = await (await get(
                ".firelight-weather__forecast-item-content-day .firelight-weather__temperature"
            )).inner_text()

            day_desc_detail = await (await get(
                ".firelight-weather__forecast-item-content-day .firelight-weather__description"
            )).inner_text()

            night_temp = await (await get(
                ".firelight-weather__forecast-item-content-night .firelight-weather__temperature"
            )).inner_text()

            night_desc_detail = await (await get(
                ".firelight-weather__forecast-item-content-night .firelight-weather__description"
            )).inner_text()

            forecast_list.append({
                "date": day_header,
                "summary": day_desc,
                "min_temp": temp_min,
                "max_temp": temp_max,
                "day": {"temp": day_temp, "description": day_desc_detail},
                "night": {"temp": night_temp, "description": night_desc_detail}
            })

        await browser.close()

    return {"city": city, "forecast": forecast_list}
