from fastapi import FastAPI, Query
from playwright.async_api import async_playwright
import asyncio

app = FastAPI(title="Eghamat24 Flight Scraper API")


@app.get("/")
async def home():
    return {"message": "Eghamat24 Flight Scraper API is running"}


@app.get("/flights")
async def get_flights(
    s_city: str = Query(..., description="شهر مبدا"),
    d_city: str = Query(..., description="شهر مقصد"),
    day: str = Query(..., description="روز پرواز (مثلاً '17')")
):
    flights = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        # ورود به صفحه
        await page.goto("https://www.eghamat24.com/search/flight?origin_city_id=112&destination_city_id=36&departure_date=2025-11-30&adult_count=2", timeout=60000)

        # صبر برای فیلد مبدا
        await page.wait_for_selector("input#search-box-flight-origin", timeout=60000)

        # وارد کردن مبدا
        await page.fill("input#search-box-flight-origin", s_city)
        await asyncio.sleep(0.5)
        await page.wait_for_selector("#search-box-flight-origin-modal .dropdown-item", timeout=20000)
        await page.click("#search-box-flight-origin-modal .dropdown-item")

        # وارد کردن مقصد
        await page.fill("input#search-box-flight-destination", d_city)
        await asyncio.sleep(0.5)
        await page.wait_for_selector("#search-box-flight-destination-modal .dropdown-item", timeout=20000)
        await page.click("#search-box-flight-destination-modal .dropdown-item")

        # -----------------------------
        # انتخاب تاریخ با HTML خاص
        # -----------------------------
        date_selector = f"span.calendar-view__day:has-text('{day}')"
        await page.wait_for_selector(date_selector, timeout=20000)
        await page.click(date_selector)
        await asyncio.sleep(0.5)

        # کلیک روی دکمه جستجو
        search_button = "button.btn.btn-primary.w-100:has-text('جستجوی بلیط')"
        await page.wait_for_selector(search_button, timeout=20000)
        await page.click(search_button, force=True)

        await asyncio.sleep(6)

        # اسکرول برای Lazy Load
        for _ in range(3):
            await page.evaluate("window.scrollBy(0, 2000)")
            await asyncio.sleep(1)

        # استخراج کارت‌های پرواز
        await page.wait_for_selector("div.flight-card-horizontal", timeout=60000)
        cards = await page.query_selector_all("div.flight-card-horizontal")

        for item in cards:
            q = lambda s: item.query_selector(s)
            qa = lambda s: item.query_selector_all(s)

            airline_el = await q("div.body-1")
            airline = await airline_el.inner_text() if airline_el else None

            flight_number_el = await q("div.flight-card-horizontal__airplane")
            flight_number = await flight_number_el.inner_text() if flight_number_el else None

            subtitle3 = await qa("div.subtitle-3")
            departure = await subtitle3[0].inner_text() if len(subtitle3) > 0 else None
            arrival = await subtitle3[1].inner_text() if len(subtitle3) > 1 else None

            cabin_el = await q("div.flight-card-horizontal__class")
            cabin = await cabin_el.inner_text() if cabin_el else None

            seats_el = await q("div.body-2.fw-semibold")
            seats_left = await seats_el.inner_text() if seats_el else None

            price_el = await q(".flight-card-horizontal__reserve-box .subtitle-3.fw-bold")
            price = await price_el.inner_text() if price_el else None

            flights.append({
                "airline": airline.strip() if airline else None,
                "flight_number": flight_number.strip() if flight_number else None,
                "departure": departure,
                "arrival": arrival,
                "cabin": cabin,
                "seats_left": seats_left,
                "price": price
            })

        await browser.close()

    return {
        "s_city": s_city,
        "d_city": d_city,
        "day": day,
        "flights": flights
    }
