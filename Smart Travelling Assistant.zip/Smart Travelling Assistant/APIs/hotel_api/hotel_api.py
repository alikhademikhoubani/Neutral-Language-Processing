from fastapi import FastAPI
from playwright.async_api import async_playwright
import asyncio

app = FastAPI(title="Hotel Scraper API")


@app.get("/")
async def home():
    return {"message": "Hotel Scraper API is running"}


@app.get("/hotels")
async def get_hotels(city: str):
    hotels = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        await page.goto("https://www.eghamat24.com/")
        await page.wait_for_selector("input#search-box-property-destination")

        # وارد کردن نام شهر
        await page.fill("input#search-box-property-destination", city)
        await asyncio.sleep(1)

        # کلیک روی اولین نتیجه
        first_item_selector = "#search-box-property-destination-modal div.flex-fill"
        await page.wait_for_selector(first_item_selector)
        await page.click(first_item_selector)

        await asyncio.sleep(1)

        # کلیک روی دکمه جستجو
        submit_button_selector = "button.gtm-search-box-property-submit"
        await page.wait_for_selector(submit_button_selector)
        await page.click(submit_button_selector)

        # صبر برای لود نتایج
        await asyncio.sleep(6)

        # آیتم‌ها
        items = await page.query_selector_all("div.card-body.d-flex")

        for item in items:
            q = lambda s: item.query_selector(s)

            name_el = await q("h3.subtitle-2")
            name = await name_el.inner_text() if name_el else None

            star_icons = await item.query_selector_all("svg.property-card-horizontal__icon-stars")
            stars = len(star_icons)

            address_el = await q("p.body-2")
            address = await address_el.inner_text() if address_el else None

            chips = []
            chip_elems = await item.query_selector_all("span.chip")
            for c in chip_elems:
                chips.append((await c.inner_text()).strip())

            price_el = await q(".subtitle-3")
            price = await price_el.inner_text() if price_el else None

            discount_el = await q(".badge-plain")
            discount = await discount_el.inner_text() if discount_el else None

            hotels.append({
                "name": name,
                "stars": stars,
                "address": address,
                "chips": chips,
                "price": price,
                "discount": discount
            })

        await browser.close()

    return {"city": city, "hotels": hotels}
