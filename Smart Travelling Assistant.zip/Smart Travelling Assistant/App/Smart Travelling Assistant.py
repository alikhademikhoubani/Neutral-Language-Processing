from typing import TypedDict, Annotated, List, Literal, Dict, Any 
from langchain_community.tools.youtube.search import YouTubeSearchTool
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langgraph.graph import StateGraph, END, MessagesState
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate 
from dotenv import load_dotenv
import os 
from langchain_core.prompts import PromptTemplate 
from youtubesearchpython import VideosSearch
import requests
from langchain_community.tools.youtube.search import YouTubeSearchTool
from langchain_classic.agents import initialize_agent, AgentType


load_dotenv()


llm = ChatGroq(model = "llama-3.3-70b-versatile")


query_input = input("\nYour Message: ")

b_prompt = f"لطفا از متن زیر فقط نام شهر مبدا را استخراج کن.\nمتن: {query_input}"
o_city = llm.invoke(b_prompt).content

c_prompt = f"لطفا از متن زیر فقط نام شهر مقصد را استخراج کن.\nمتن: {query_input}"
d_city = llm.invoke(c_prompt).content

date_prompt = f"لطفا از متن زیر فقط تاریخ را به صورت عددی استخراج کن. برای مثال اگر در متن تاریخ بدین صورت مشخص گردیده است: 'من می خواهم هفدهم به سفر بروم'، باید پاسخ شما فقط عدد 17 باشد.\nمتن: {query_input}"
day = llm.invoke(date_prompt).content


class SupervisorState(MessagesState):
    """State for the multi-agent"""
    next_agent: str = "supervisor"
    forecast_data: str = ""
    hotel_data: str = ""
    flight_data: str = ""
    youtube_data: str = ""
    final_report: str = ""
    task_complete: bool = False
    current_task: str = ""
    final_forecast: str = ""
    final_hotel: str = ""
    final_flight: str = ""
    final_youtube: str = ""


def create_supervisor_chain():
    """Creates the supervisor decision chain"""
    supervisor_prompt = ChatPromptTemplate.from_messages([
        ("system", """تو در نقش یک ناظر هستی که یک تیم از ایجنت ها را مدیریت می کند:

1. forecast: داده های مربوط به هواشناسی یک شهر خاص را ارائه می کند.
2. hotel: داده های مربوط به هتل های موجود در یک شهر خاص را ارائه می کند.
3. flight: داده های مربوط به پروازهای موجود از یک شهر خاص به یک شهر خاص دیگر را ارائه می کند.
4. youtube: ویدیویی برای معرفی یک شهر خاص را ارائه می کند.
5. writer: بر اساس داده های جمع آوری شده از ایجنت های دیگر، یک گزارش کلی ارائه می کند.

بر اساس حالت فعلی و گفتگو، تصمیم بگیر کدام ایجنت باید در حالت بعدی مورد استفاده قرار گیرد.
اگر وظیفه انجام شد، با کلمه "done" پاسخ بده.

حالت فعلی: 
- آیا داده هواشناسی را دارد: {has_forecast}
- آیا داده هتل ها را دارد: {has_hotel}
- آیا داده پروازها را دارد: {has_flight}
- آیا داده یوتیوب را دارد: {has_youtube}
- آیا داده گزارش را دارد: {has_report}

فقط نام ایجنت، یعنی یکی از نام های زیر را در پاسخ خود ارائه کن:
"forecast" / "hotel" / "flight" / "youtube" / "writer"
"""),
        ("human", "{task}")
    ])

    return supervisor_prompt | llm


def supervisor_agent(state: SupervisorState) -> Dict:
    messages = state.get("messages", [])
    current_task = state.get("current_task", "")

    if not current_task:
        human_msgs = [m for m in messages if isinstance(m, HumanMessage)]
        if human_msgs:
            current_task = human_msgs[-1].content.strip()
        else:
            current_task = "هیچ وظیفه ای وجود ندارد"

    has_forecast = bool(state.get("forecast_data"))
    has_hotel = bool(state.get("hotel_data"))
    has_flight = bool(state.get("flight_data"))
    has_youtube = bool(state.get("youtube_data"))
    has_report = bool(state.get("final_report"))

    chain = create_supervisor_chain()
    decision = chain.invoke({
        "task": current_task,
        "has_forecast": has_forecast,
        "has_hotel": has_hotel,
        "has_flight": has_flight,
        "has_youtube": has_youtube,
        "has_report": has_report
    })

    decision_text = decision.content.strip().lower()
    print(f"Supervisor decision: {decision_text}")

    if "done" in decision_text or has_report:
        next_agent = "__end__"
        supervisor_msg = "ناظر: تمام وظایف کامل شد! کار تیمی عالی بود."
    elif "hotel" in decision_text or (has_forecast and not has_hotel):
        next_agent = "hotel"
        supervisor_msg = "ناظر: داده های مربوط به هواشناسی توسط ایجنت forecast جمع آوری شد. اکنون زمان جمع آوری داده های هتل های موجود توسط ایجنت hotel است."
    elif "flight" in decision_text or (has_hotel and not has_flight):
        next_agent = "flight"
        supervisor_msg = "ناظر: داده های مربوط به هتل های موجود توسط ایجنت hotel جمع آوری شد. اکنون زمان جمع آوری داده های پروازهای موجود توسط ایجنت flight است."
    elif "youtube" in decision_text or (has_flight and not has_youtube):
        next_agent = "youtube"
        supervisor_msg = "ناظر: داده های مربوط به پروازهای موجود توسط ایجنت flight جمع آوری شد. اکنون زمان ارائه ویدیویی در مورد شهر مقصد توسط ایجنت youtube است."
    elif "writer" in decision_text or (has_youtube and not has_report):
        next_agent = "writer"
        supervisor_msg = "ناظر: ویدیوی معرفی یک شهر توسط ایجنت youtube جمع آوری شد. اکنون زمان نوشتن یک گزارش از داده های جمع آوری شده از ایجنت های forecast و hotel و flight و youtube توسط ایجنت writer می باشد."
    else:
        next_agent = "forecast"
        supervisor_msg = "ناظر: شروع با ایجنت forecast برای جمع آوری اطلاعات."

    return {
        "messages": state["messages"] + [AIMessage(content = supervisor_msg)],
        "next_agent": next_agent,
        "current_task": current_task
    }



def forecast_agent(state: SupervisorState) -> Dict:
    """Gathers forecast data for destination city"""
    response = requests.get("http://127.0.0.1:9000/weather", params = {"city": d_city})
    response_data = response.json()

    agent_message = f"forecast: من داده های هواشناسی شهر مقصد را جمع آوری کردم. \n\n داده های جمع آوری شده:\n{response_data}"

    return {
        "messages": state["messages"] + [AIMessage(content = agent_message)],
        "forecast_data": response_data,
        "next_agent": "supervisor"
    }



def hotel_agent(state: SupervisorState) -> Dict:
    """Gathers hotel data for destination city"""
    response = requests.get("http://127.0.0.1:9001/hotels", params = {"city": d_city})
    response_data = response.json()

    agent_message = f"hotel: من داده های هتل های موجود در شهر مقصد را جمع آوری کردم. \n\n داده های جمع آوری شده:\n{response_data}"

    return {
        "messages": state["messages"] + [AIMessage(content = agent_message)],
        "hotel_data": response_data,
        "next_agent": "supervisor"
    }



def flight_agent(state: SupervisorState) -> Dict:
    """Gathers flight data from origin city to destination city"""
    url = "http://127.0.0.1:9002/flights"
    params = {
    "s_city": o_city,
    "d_city": d_city,
    "day": day
    }

    response = requests.get(url, params=params)
    response_data = response.json()

    agent_message = f"flight: من داده های پروازهای موجود از شهر مبدا به شهر مقصد را جمع آوری کردم. \n\n داده های جمع آوری شده:\n{response_data}"

    return {
        "messages": state["messages"] + [AIMessage(content = agent_message)],
        "flight_data": response_data,
        "next_agent": "supervisor"
    }



def youtube_agent(state: SupervisorState) -> Dict:
    """Provide youtube links for representing destination city"""
    prompt_template = PromptTemplate(
    template = """
    در مورد موضوع {subject} به تعداد {number} ویدیو به من ارائه کن. ویدیوهایی که به من ارائه می کنی، باید مرتبط ترین و جدیدترین ویدیوها با موضوع مورد نظر باشند.
    """,
    input_variables = ["subject", "number"]
    )


    youtube_tool = YouTubeSearchTool(description = "جستجوی ویدیوهای مرتبط در YouTube. ورودی باید به صورت <موضوع>، <تعداد> باشد.")


    tools = [youtube_tool]


    agent = initialize_agent(
        tools,
        llm = llm,
        agent = AgentType.ZERO_SHOT_REACT_DESCRIPTION,
        handle_sparsing_errors = True,
        verbose = False
    )

    subject = f"آشنایی با شهر {d_city}"
    number = 2

    response = agent.invoke(prompt_template.format(subject = subject, number = number).strip())

    agent_message = f"youtube: من لینک های ویدیوی مربوط به معرفی شهر مقصد را جمع آوری کردم.\n\nلینک های جمع آوری شده:\n{response}"

    return {
        "messages": state["messages"] + [AIMessage(content = agent_message)],
        "youtube_data": response,
        "next_agent": "supervisor"
    }



def writer_agent(state: SupervisorState) -> Dict:
    """Uses all of the gathered information by other agents to write a final report"""
    forecast_data = state.get("forecast_data", "")
    hotel_data = state.get("hotel_data", "")
    flight_data = state.get("flight_data", "")
    youtube_data = state.get("youtube_data", "")
    task = state.get("current_task")

    writing_prompt = f"""
تو نقش یک نویسنده حرفه‌ای گزارش را داری. وظیفه تو این است که یک گزارش کامل مرحله‌ای برای سفر از شهر {o_city} به {d_city} بر اساس داده‌های جمع‌آوری شده ارائه دهی.

داده‌ها:
1. هواشناسی: {forecast_data}
2. هتل‌ها: {hotel_data}
3. پروازها: {flight_data}
4. ویدیوهای معرفی: {youtube_data}

دستورالعمل:
- گزارش را در ۴ گام تولید کن:
  **گام اول: تحلیل هواشناسی** (حدود 500 کلمه)
  **گام دوم: تحلیل هتل‌ها** (حدود 1500 کلمه): ابتدا داد های هتل را در یک فرمت مناسب به کاربر نمایش بده و سپس بهترین هتل ها را از نطر امکانات و قیمت ارائه کن و آدرس آن را نیز به کاربر ارائه بده. توجه داشته باش قیمت ها برای دو شب اقامت هستند.
  **گام سوم: تحلیل پروازها** (حدود 1500 کلمه): ابتدا داده های پروازها را در یک فرمت مناسب به کاربر نمایش بده. سپس بهترین پرواز را از نظر امکاناتی نظیر طول سفر و غیره به همراه تمام ویژگی های آن ارائه کن.
  **گام چهارم: لینک ویدیوی معرفی و جمع‌بندی نهایی** (حدود 300 کلمه)
- هر گام باید جدا و با عنوان مشخص ارائه شود.
- از داده‌ها مستقیماً استفاده کن و تحلیل کامل بده.
- از بیان فرایند تولید متن در پاسخ خودداری کن.
- پاسخ را به یک متن واحد و کامل بده، نه بخش‌بخش.

خروجی باید قابل نمایش به کاربر باشد و شامل تمام تحلیل‌ها و جمع‌بندی نهایی باشد.
"""

    report_response = llm.invoke([HumanMessage(content = writing_prompt)])
    report = report_response.content

    final_report = f"""
    گزارش نهایی
{'=' * 50}
موضوع: {task}
{'=' * 50}

{report}
"""

    return {
        "messages": state["messages"] + [AIMessage(content = f"نویسنده: گزارش کامل شد! سند کامل در زیر قابل دیدن است.\n{final_report}")],
        "final_report": final_report,
        "next_agent": "supervisor",
        "task_complete": True
    }


def router(state: SupervisorState):
    next_agent = state.get("next_agent", "supervisor")

    if next_agent in ["__end__", "end"] or state.get("task_complete", False):
        return END
    
    if next_agent in ["supervisor", "forecast", "hotel", "flight", "youtube", "writer"]:
        return next_agent

    return "supervisor"



workflow = StateGraph(SupervisorState)

workflow.add_node("supervisor", supervisor_agent)
workflow.add_node("forecast", forecast_agent)
workflow.add_node("hotel", hotel_agent)
workflow.add_node("flight", flight_agent)
workflow.add_node("youtube", youtube_agent)
workflow.add_node("writer", writer_agent)

workflow.set_entry_point("supervisor")

for node in ["supervisor", "forecast", "hotel", "flight", "youtube", "writer"]:
    workflow.add_conditional_edges(
        node,
        router,
        {
            "supervisor": "supervisor",
            "forecast": "forecast",
            "hotel": "hotel",
            "flight": "flight",
            "youtube": "youtube",
            "writer": "writer",
            "__end__": END
        }
    )

graph = workflow.compile()


response = graph.invoke({
    "messages": [HumanMessage(content = query_input)]
})


forecast_output = response['messages'][2].content
hotel_output = response['messages'][4].content
flight_output = response['messages'][6].content
youtube_output = response['messages'][8].content
report_output = response['messages'][10].content

print("داده های هواشناسی شهر مقصد:\n", forecast_output)
print("داد های هتل های مقصد:\n", hotel_output)
print("داده های پرواز از شهر مبدا به شهر مقصد:\n", flight_output)
print("لینک های ویدیوی معرفی شهر مقصد:\n", youtube_output)
print("گزارش نهایی:\n", report_output)