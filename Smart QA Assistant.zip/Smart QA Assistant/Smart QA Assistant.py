import streamlit as st 
from langchain_groq import ChatGroq
import PyPDF2 as pdf
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.docstore.document import Document
from langchain.vectorstores import FAISS
from langchain.chains import RetrievalQAWithSourcesChain
from langchain.prompts import PromptTemplate


llm = ChatGroq(
    model_name = "llama-3.3-70b-versatile",
    groq_api_key = "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",
    temperature = 0
)


def pdf_input_text(uploaded_file):
    reader = pdf.PdfReader(uploaded_file)
    text = ""
    for page in reader.pages:
        extracted = page.extract_text()
        if extracted:
            text += extracted
    return text


def get_chunks(text):
    text_splitter = RecursiveCharacterTextSplitter(
        separators = ["\n\n", "\n", " "],
        chunk_size = 1500,
        chunk_overlap = 150
    )
    chunks = text_splitter.split_text(text)
    return chunks 



def get_vectordb(chunks, embeddings):
    documents = [Document(page_content = chunk, metadata = {"source": f"chunk_{i}"}) for i, chunk in enumerate(chunks)]
    vector_db = FAISS.from_documents(documents, embeddings)
    return vector_db


def get_chain(llm, vector_db):
    chain = RetrievalQAWithSourcesChain.from_llm(
        llm = llm,
        retriever = vector_db.as_retriever()
    )
    return chain


prompt_template = PromptTemplate(
    template = """
    لطفا با توجه به اطلاعاتی که در اختیار داری، به سوال زیر پاسخ دقیق ارائه کن. پاسخ حتما باید به زبان فارسی باشد:
    سوال: {question}
    """,
    input_variables = ["question"]
)


embeddings = HuggingFaceEmbeddings(model_name = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")



st.title("پاسخگوی سوالات از اسناد")
st.text("سوالات خود را بپرسید")
prompt = st.text_area("بپرسید")
uploaded_file = st.file_uploader("سند مورد نظر را بارگذاری کنید", type = "pdf", help = "لطفا پی دی اف را بارگذاری کنید")

submit = st.button("Submit")


if submit:
    if uploaded_file is not None:
        text = pdf_input_text(uploaded_file)
        chunks = get_chunks(text)
        vector_db = get_vectordb(chunks, embeddings)
        chain = get_chain(llm, vector_db)
        if prompt:
            response = chain(prompt_template.format(question = prompt))
            st.write(response["answer"])
        else:
            st.warning("لطفا سوال خود را وارد کنید")
