from langchain_groq import ChatGroq
import PyPDF2 as pdf
from langchain.embeddings import HuggingFaceEmbeddings
import streamlit as st 
from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_astradb import AstraDBVectorStore
from langchain.prompts import ChatPromptTemplate
from langchain.schema.runnable import RunnablePassthrough
from langchain.schema.output_parser import StrOutputParser

llm = ChatGroq(
    model = "llama-3.3-70b-versatile",
    groq_api_key = "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",
    temperature = 0
)

def vector_store():
    if "vstore" not in st.session_state:
        st.session_state.texts = ""
        st.session_state.reader = pdf.PdfReader("C:/Users/Lenovo/Desktop/New folder (6)/rooze.pdf")
        for page in st.session_state.reader.pages:
            st.session_state.extracted = page.extract_text()
            if st.session_state.extracted:
                st.session_state.texts += st.session_state.extracted
        
        st.session_state.splitter = RecursiveCharacterTextSplitter(
            separators = ["\n\n", "\n", " "],
            chunk_size = 1500,
            chunk_overlap = 150
        )
        st.session_state.chunks = st.session_state.splitter.split_text(st.session_state.texts)

        st.session_state.docs = [Document(page_content = chunk) for chunk in st.session_state.chunks]

        st.session_state.embeddings = HuggingFaceEmbeddings(model_name = "sentence-transformers/all-MiniLM-L6-v2")

        st.session_state.vstore = AstraDBVectorStore(
            collection_name = "test2",
            embedding = st.session_state.embeddings,
            token = "AstraCS:MJUYSyYGioSHvLYSePgGJCbG:a6571d8b382bbf9b1fa9b5787658fac5a7cfc59298ed41073334e7b3d8907c35",
            api_endpoint = "https://43b50bc3-a525-4afb-adfd-3581a6768632-us-east-2.apps.astra.datastax.com"
        )

        st.session_state.vstore.add_documents(st.session_state.docs)


prompt = ChatPromptTemplate.from_template(
    """
    فقط بر اساس متن ارائه شده، به سوال پاسخ دقیق بده. پاسخی که می دهی باید کامل و جامع باشد.
    اگر پاسخ سوال پرسیده شده، در متن ارائه شده نبود، بگو نمی دانم.
    متن: {context}
    سوال: {question}
    """
)



if st.button("Get Ready Vector Store"):
    if "vstore" not in st.session_state:
        vector_store()



input_text = st.text_input("Enter your query")
if input_text:
    retriever = st.session_state.vstore.as_retriever(search_kwargs = {"k": 3})

    def combine_docs(docs):
        return "\n\n".join([d.page_content for d in docs])

    chain = (
        {"context": retriever | combine_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    st.write(chain.invoke(input_text))