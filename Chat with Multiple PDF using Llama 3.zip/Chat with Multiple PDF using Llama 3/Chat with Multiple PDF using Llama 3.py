from PyPDF2 import PdfReader
from langchain.text_splitter import RecursiveCharacterTextSplitter
import os
from langchain_google_genai import GoogleGenerativeAIEmbeddings
import google.generativeai as genai
from langchain.vectorstores import FAISS
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.chains.question_answering import load_qa_chain
from langchain.prompts import PromptTemplate

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage, SystemMessage
import google.generativeai as genai
from langchain_groq import ChatGroq
from dotenv import load_dotenv
from langchain.embeddings import HuggingFaceEmbeddings
import streamlit as st

llm1 = ChatGroq(
    model_name = "llama-3.3-70b-versatile",
    groq_api_key = "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",
    temperature = 0
)

def get_pdf_text(pdf_docs):
    text = ""
    for pdf in pdf_docs:
        pdf_reader = PdfReader(pdf)
        for page in pdf_reader.pages:
            text += page.extract_text()
    return text

def get_text_chunks(text):
    text_splitter = RecursiveCharacterTextSplitter(
        separators = ["\n\n", "\n", " "],
        chunk_size = 4000,
        chunk_overlap = 200
    )
    chunks = text_splitter.split_text(text)
    return chunks

def get_vector_store(chunks):
  embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
  vector_store = FAISS.from_texts(chunks, embedding = embeddings)
  return vector_store

def get_embedding_vectors(pdf_docs):
  text = get_pdf_text(pdf_docs)
  chunks = get_text_chunks(text)
  vector_store = get_vector_store(chunks)
  vector_store.save_local('faiss_index')

def user_input(user_prompt):

  prompt_template = """
  Answer the question as detailed as possible from the provided context, make sure to provide all the details, if the answer is not in
  provided context just say, "answer is not available in the context", don't provide the wrong answer\n\n
  Context:\n {context}\n
  Question: \n{question}?\n

  Answer:
  """


  prompt = PromptTemplate(template = prompt_template, input_variables = ["context", "question"])

  embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

  new_db = FAISS.load_local("faiss_index", embeddings, allow_dangerous_deserialization=True)
  doc = new_db.similarity_search(user_prompt)
  chain = load_qa_chain(
      llm1,
      chain_type = "stuff",
      prompt = prompt
  )

  response = chain({"input_documents": doc, "question": user_prompt}, return_only_outputs = True)
  
  print(response)

  st.write("Reply: ", response["output_text"])


def main():
    st.set_page_config("Chat With Multiple PDF")
    st.header("Chat with Multiple PDF using Llama 3")

    user_question = st.text_input("Ask a Question from the PDF Files")

    if user_question:
        user_input(user_question)

    with st.sidebar:
        st.title("Menu:")
        pdf_docs = st.file_uploader("Upload your PDF Files and Click on the Submit & Process", type=["pdf"], accept_multiple_files=True)
        if st.button("Submit & Process"):
            with st.spinner("Processing..."):
                raw_text = get_pdf_text(pdf_docs)
                text_chunks = get_text_chunks(raw_text)
                vector_store = get_vector_store(text_chunks)
                vector_store.save_local("faiss_index")
                st.success("Done")


if __name__ == "__main__":
    main()
